<img align="right" src="https://count.getloli.com/get/@:Minori-ty?theme=rule34">

## 前端工程师—天平

热爱前端、热爱技术。工作经验1年。喜欢参与一些开源项目的讨论。

### **社交主页：**

 <img align="right" alt="GIF" src="./images/code.gif" width="430" height="100%" />


-   <a href="https://juejin.cn/user/1214304985296439/posts"><code><img height="20" width="50" src="./images/juejin.png"></code></a>：掘金优秀作者，发表了 30 篇技术文章，15万阅读。

### **技术栈:**

<a href="https://v3.cn.vuejs.org"><code><img height="20" src="./images/vue.png"></code></a>
<a href="https://reactjs.org/"><code><img height="20" src="./images/react.svg"></code></a>
<a href="https://nextjs.org/"><code><img height="20" src="./images/next.png"></code></a>
<a href="https://www.tslang.cn/index.html"><code><img height="20" src="./images/typescript.png"></code></a>
<a href="https://webpack.js.org/"><code><img height="20" src="./images/webpack.svg"></code></a>
<a href="https://cn.vitejs.dev"><code><img height="20" src="./images/vite.png"></code></a>
<a href="https://sass-lang.com"><code><img height="20" src="./images/sass2.png"></code></a>
<a href="https://tailwindcss.com"><code><img height="20" src="./images/tailwindcss.png"></code></a>
<a href="https://go.dev/"><code><img height="20" src="./images/golang.png"></code></a>
<a href="https://www.docker.com"><code><img height="20" src="./images/docker.png"></code></a>

### 开源项目

[![](https://github-readme-stats.vercel.app/api/pin/?username=Minori-ty&repo=mp4To4K-rust)](https://github.com/Minori-ty/mp4To4K-rust)
<br><br><br>

### Github 活跃度

[![](https://activity-graph.herokuapp.com/graph?username=Minori-ty&theme=dracula)](https://github.com/ashutosh00710/github-readme-activity-graph)
![Minori-ty's github stats](https://github-readme-stats.vercel.app/api?username=Minori-ty&show_icons=true&theme=vue)

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Minori-ty&langs_count=6)
![](https://github-readme-stats.vercel.app/api/top-langs/?username=Minori-ty&layout=compact&langs_count=6)
